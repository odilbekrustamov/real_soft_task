import 'package:flutter/material.dart';
import 'package:m_toast/m_toast.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:motion_toast/resources/arrays.dart';

class Utils{

  static void showToastSuccess(String msg, BuildContext context) {
    ShowMToast toast = ShowMToast(context);
    toast.successToast(
        message: msg,
        backgroundColor: Colors.white,
        alignment: Alignment.topCenter,
        duration: 300,
        width: 10
    );
  }

}