package com.example.real_soft_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
